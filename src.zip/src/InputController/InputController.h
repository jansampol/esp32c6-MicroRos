#pragma once
#include <Arduino.h>
#include <vector>
#include <span>
#include <Adafruit_GFX.h>
#include <memory>
#include "SystemParameters.h"
#include "InputController/InputStructs.h"

// other spi devices (ui & external)
#include "InputController/SPI/SPI0Manager.h"
#include "InputController/I2C/I2CManager.h"
#include "InputController/MamriWebServer.h"
#include "InputController/CanvasManager.h"

#include "RobotController/RobotController.h"

class InputController {
    public:

        // Constructor
        InputController(InputModes defaultMode);
        void begin();
        void beginWebserver();
        void webserverAttachRobotController(RobotController & robotController);
        void testSPI0Manager();
        void setMainValve(bool on);
        void setScreenRES(bool on);
        void setScreenBLK(bool on);

        
        void update(RobotController & robotController);

        std::vector<float> readFerrisWheelAngles();
        std::vector<float> readFerrisWheelValues();
        void updateNumOfFerrisWheels(uint8_t numOfFerrisWheels);
        
        Page mapPagePotmeter();
        float getMaxVelocityFromPotmeter();

        void handleHorizontalButtons(RobotController & robotController, bool jointMode);
        void handleVerticalButtons(RobotController & robotController);
        void handleSwitches(RobotController & robotController);

        void setInputMode(InputModes newMode);
        InputModes getInputMode();
        void setLedEmergency(bool on){
            _spi0Manager.writeRed3(on);
        }
        bool getFerrisWheelsReady(){
            return _ferrisWheelsReady;
        }

        SPI0Manager& getSPI0Manager(){ return _spi0Manager; }
    
    private:      
        SPI0Manager _spi0Manager;
        I2CManager _i2cManager;

        InputModes _defaultInputMode;
        InputModes _currentInputMode;

        MamriWebServer _mamriWebServer;

        // canvas is passed to spi0manager to update screen
        // Allocate on heap to preserve free heap for AsyncWebServer startup
        //std::unique_ptr<GFXcanvas1> _canvas;
        CanvasManager _canvasManager;
        // unique_ptr will free _canvas automatically

        // int _lastPot0Value = 0;
        // int _lastPot1Value = 0;

        bool _ferrisWheelsReady = false;

        // 16 bits old vbutton state
        uint16_t _lastVerticalButtonState = 0;

    public:
        ~InputController() = default;
};
