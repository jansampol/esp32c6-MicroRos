/*
    SPI1 is simpler than SPI0 bus as there is only one MCP device. This triggers the motor valves.
*/

#pragma once
#include <Arduino.h>
#include "PinDefinitions.h"     
#include <SPI.h>
//#include "InputController/SPI/MCP23S17_v3.h"
#include <MCP23S17.h>


class SPI1Manager{
    /// more like Chip select manager
    public:

        // Constructor
        SPI1Manager();
        bool begin();
        void selectDevice();
        void deselectDevice();
        void writeValves(uint16_t ledStates);
        uint16_t getValveStates();

    private:
        uint16_t _valveStates = 0;
        MCP23S17 _motorValves;
};