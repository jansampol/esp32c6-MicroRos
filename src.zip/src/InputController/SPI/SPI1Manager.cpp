#include "InputController/SPI/SPI1Manager.h"
#include <SPI.h>

SPIClass SPI1(FSPI);

SPI1Manager::SPI1Manager() :
// Initialize MCP23S17 instances
    // Cannot be changed to hardware SPI
    _motorValves(SPI1_CS_MOTOR, SPI1_MISO_PIN, SPI1_MOSI_PIN, SPI1_CLK_PIN, 0x00)
    //_motorValves(SPI1_CS_MOTOR, &SPI1)
{

}

bool SPI1Manager::begin(){
    /*
    SPI1.begin(
        SPI1_CLK_PIN,   // SCK
        SPI1_MISO_PIN,  // MISO
        SPI1_MOSI_PIN,  // MOSI
        -1
    );*/

    // set spi1 as correct i/o. was previously done in each MCP23S17 .begin() call. Do here once.
    /*
    pinMode(SPI1_MISO_PIN, INPUT);
    pinMode(SPI1_MOSI_PIN, OUTPUT);
    pinMode(SPI1_CLK_PIN, OUTPUT);
    pinMode(SPI1_CS_MOTOR, OUTPUT);
    */

    //selectDevice();
    if(!_motorValves.begin()){
        Serial.println("---- Motor MCP23S17 failed to initialize! ----");
    }
    //selectDevice();
    _motorValves.pinMode16(0X0000); // all outputs
    //deselectDevice();
    return true;
}

/*
void SPI1Manager::selectDevice(){
    // toggle the motor CS pin.
    digitalWrite(SPI1_CS_MOTOR, HIGH);
    // mircoseconds delay
    delayMicroseconds(1);
    digitalWrite(SPI1_CS_MOTOR, LOW);
}

void SPI1Manager::deselectDevice(){
    // toggle the motor CS pin.
    digitalWrite(SPI1_CS_MOTOR, LOW);
    // mircoseconds delay
    delayMicroseconds(1);
    digitalWrite(SPI1_CS_MOTOR, HIGH);

}
*/

void SPI1Manager::writeValves(uint16_t valveStates){
    _valveStates = valveStates;
    //selectDevice();
    _motorValves.write16(valveStates);
    //deselectDevice();
}

uint16_t SPI1Manager::getValveStates(){
    return _valveStates;
}