#include "InputController/InputController.h"

// Constructor
InputController::InputController(InputModes defaultMode)
    : _spi0Manager(),
    _i2cManager(),
    _mamriWebServer(),
    _canvasManager(*this, _spi0Manager)
{
    _defaultInputMode = defaultMode;
    _currentInputMode = defaultMode;
}

// Destructor is defaulted in the header; unique_ptr manages the canvas lifetime

void InputController::begin() {
    Serial.printf("Total PSRAM: %d bytes\n", ESP.getPsramSize());
    Serial.printf("Free PSRAM: %d bytes\n", ESP.getFreePsram());

    // start SPI0 bus
    _spi0Manager.begin();

    // Create canvas
    _canvasManager.initCanvas();

    // Test all spi0 devices
    testSPI0Manager();

    // Start screen
    _canvasManager.initScreen();
    
    #if ESP_ATTACHED
        // start I2C bus
        if(_i2cManager.begin(NUM_OF_FERRISWHEELS_ON_BOOT, 0)){
            _ferrisWheelsReady = true;
            // read all ferriswheels
            Serial.println();
            for(int i = 0; i < _i2cManager.getNumOfFerrisWheels(); i++){
                float angle = _i2cManager.readFerrisWheelAngle(i);

                // Serial.print("Ferris Wheel ");
                // Serial.print(i);
                // Serial.print(" Angle: ");
                // Serial.println(angle);
            }
            Serial.println("Ferris wheels ready.");
        } else {
            Serial.println("Ferris wheels not ready.");
            _ferrisWheelsReady = false;
        }

    #endif

    Serial.println("Re-read potmeters:");
    Serial.print("ADC Potmeter 0: ");
    Serial.println(_spi0Manager.readPotmeters(0));
    Serial.print("ADC Potmeter 1: ");
    Serial.println(_spi0Manager.readPotmeters(1));


    // Allocate canvas after webserver start to preserve heap for AsyncWebServer
    /*
    if (!_canvas) {
        _canvas = std::make_unique<GFXcanvas1>(SCREEN_WIDTH, SCREEN_HEIGHT);
    }
    */
}

void InputController::testSPI0Manager() {
    Serial.println("Valve open");
    _spi0Manager.setMainValve(true);
    _spi0Manager.setMainValve(false);

    // does nothing rn
    // _spi0Manager.setScreenBLK(true);
    // _spi0Manager.setScreenRES(true);

    _spi0Manager.writeLeds(0x00);
    _spi0Manager.writeGreen(true);
    delay(30);
    _spi0Manager.writeLeds(0x00);
    _spi0Manager.writeRed1(true);
    delay(40);
    _spi0Manager.writeLeds(0x00);
    _spi0Manager.writeRed2(true);
    delay(50);
    _spi0Manager.writeLeds(0x00);
    _spi0Manager.writeRed3(true);
    delay(60);
    _spi0Manager.writeLeds(0x00);
    _spi0Manager.writeYellow(true);
    delay(70);
    _spi0Manager.writeLeds(0x00);
    _spi0Manager.writeBlue(true);
    delay(80);
    _spi0Manager.writeLeds(0x00);
    _spi0Manager.writeGreen(true);
    delay(30);
    _spi0Manager.writeLeds(0x00);
    _spi0Manager.writeRed1(true);
    delay(40);
    _spi0Manager.writeLeds(0x00);
    _spi0Manager.writeRed2(true);
    delay(50);
    _spi0Manager.writeLeds(0x00);
    _spi0Manager.writeRed3(true);
    delay(60);
    _spi0Manager.writeLeds(0x00);
    _spi0Manager.writeYellow(true);
    delay(70);
    _spi0Manager.writeLeds(0x00);
    _spi0Manager.writeBlue(true);
    delay(80);
    _spi0Manager.writeLeds(0x00);
    _spi0Manager.writeGreen(true);


    Serial.print("Switches: ");
    Serial.println(_spi0Manager.readSwitches(), BIN);

    Serial.print("Horizontal Buttons: ");
    Serial.println(_spi0Manager.readHorizontalButtons(), BIN);

    Serial.print("Vertical Buttons: ");
    Serial.println(_spi0Manager.readVerticalButtons(), BIN);

    Serial.print("ADC Potmeter 0: ");
    Serial.println(_spi0Manager.readPotmeters(0));
    Serial.print("ADC Potmeter 1: ");
    Serial.println(_spi0Manager.readPotmeters(1));

    // Serial.println("External MCP1: ");
    // _spi0Manager.writeExternalDevice(EXTERNAL_MCP_1, 0xFFFF);
    // delay(500);
    // _spi0Manager.writeExternalDevice(EXTERNAL_MCP_1, 0x0000);
    // delay(500);
    // _spi0Manager.writeExternalDevice(EXTERNAL_MCP_1, 0xFFFF);
    // Serial.println();
}


std::vector<float> InputController::readFerrisWheelAngles(){
    // Read ferris wheel angles and send to robot controller
    if(!_ferrisWheelsReady){
        return {};
    }
    return _i2cManager.readAllFerrisWheelAngles();

}

std::vector<float> InputController::readFerrisWheelValues(){
    // Read ferris wheel raw values and send to robot controller
    if(!_ferrisWheelsReady){
        return {};
    }
    return _i2cManager.readAllFerrisWheelRawValues();
}

void InputController::updateNumOfFerrisWheels(uint8_t numOfFerrisWheels){
    // only reinit the number of ferris wheels, not the number of multiplexers
    #if ESP_ATTACHED
    Serial.printf("InputController::updateNumOfFerrisWheels: calling _i2cManager.initFerrisWheels(%d)\n", numOfFerrisWheels);
    _ferrisWheelsReady = _i2cManager.initFerrisWheels(numOfFerrisWheels);
    #else
    _ferrisWheelsReady = false;
    #endif
}


void InputController::beginWebserver() {
    // done early in the loop to allow heap for AsyncWebServer
    _mamriWebServer.begin();
}

void InputController::webserverAttachRobotController(RobotController & robotController) {
    // done after robot controller is initialized
    _mamriWebServer.attachRobotController(&robotController);
}

// -------------------------------------------------- UPDATE FUNCTION ---------------------------------

void InputController::update(RobotController & robotController) {
    handleSwitches(robotController);

    // Set blue LED state and IK mode in robotController based on input mode
    if(_currentInputMode != BUTTON_EE_CONTROL_MODE){
        _spi0Manager.writeBlue(false);
        robotController.disableIK();
    } else {
        _spi0Manager.writeBlue(true);
        robotController.enableIK();
    }

    // Handle this input mode
    switch (_currentInputMode) {
        case BUTTON_JOINT_MODE:
            // Handle button inputs with direct joint control
            robotController.setControlStrategy(PneumaticStepper::Controlstrategy::VELOCITY_CONTROL);
            handleHorizontalButtons(robotController, true);
            break;
        case BUTTON_EE_CONTROL_MODE:
            // Handle button inputs with position control
            robotController.setControlStrategy(PneumaticStepper::Controlstrategy::POSITION_CONTROL);
            handleHorizontalButtons(robotController, false);
            break;
        // add other modes here (based on INPUTMODE enum)
        case JOINT_TARGET_MODE:
            robotController.setControlStrategy(PneumaticStepper::Controlstrategy::POSITION_CONTROL);
            break;
        default:
            // Unknown mode, revert to default
            _currentInputMode = _defaultInputMode;
            break;
    }

    _mamriWebServer.updateInputMode(_currentInputMode);
    _mamriWebServer.updateFerrisWheelsReady(_ferrisWheelsReady);

    // Set page mode and update canvas
    _canvasManager.selectPage(mapPagePotmeter());
    _canvasManager.updateDirect(_canvasManager.getCanvas(), _currentInputMode, robotController);

    // send canvas to physical screen
    _spi0Manager.selectDevice(SCREEN);
    uint16_t* buf = (uint16_t*)_canvasManager.getCanvas().getBuffer();
    _spi0Manager.getScreen().drawRGBBitmap(0, 0, buf, _canvasManager.WIDTH, _canvasManager.HEIGHT);
    _spi0Manager.deselectDevice();

    // read pressure, if below 2 bar, set red2 on
    #if ESP_ATTACHED
    if(_i2cManager.readPressureSensor(0) < 2.0f){
        _spi0Manager.writeRed2(true);
    } else {
        _spi0Manager.writeRed2(false);
    }
    #endif

    // handle vertical buttons
    handleVerticalButtons(robotController);

    float maxVelocity = getMaxVelocityFromPotmeter();
    robotController.setFrequency(maxVelocity);

    // if pot meter 1 is positive (= has significant change), set frequency to the new value
    /*
    if(mapPotmeter1() > 0){
        robotController.setFrequency(_lastPot1Value);
    }
    */

    // When the ferris wheels are not ready, but there should be ferris wheels, turn on red1 led
    if(!_ferrisWheelsReady && robotController.getNumOfFerrisWheels() > 0){
        _spi0Manager.writeRed1(true);
    } else {
        _spi0Manager.writeRed1(false);
    }
}

Page InputController::mapPagePotmeter() {
    int potValue = _spi0Manager.readPotmeters(0); // Read potmeter 0 value (0-1023)
    // Map potmeter value to pages
    if (potValue < 171) {
        return Page::HOME;
    } else if (potValue < 400) {
        return Page::ROBOTINFO;
    } else if (potValue < 682) {
        return Page::STEPPER_POSITIONS;
    } else {
        return Page::END_EFFECTOR_POSITION;
    }
}

float InputController::getMaxVelocityFromPotmeter()
{
    const float POTMETER_MIN_FREQ = 1.0f;
    const float POTMETER_MAX_FREQ = 100.0f;
    int potValue = _spi0Manager.readPotmeters(1);
    return POTMETER_MIN_FREQ * exp(log(POTMETER_MAX_FREQ / POTMETER_MIN_FREQ) * potValue / 1023.0);
}


/*
int InputController::mapPotmeter1() {
    int potValue = _spi0Manager.readPotmeters(1); // Read potmeter 1 value (0-1023)

    // if new value is significantly different from last value, update
    if (abs(potValue - _lastPot1Value) > 5) {
        _lastPot1Value = map(potValue, 0, 1023, 1, MAX_MOTOR_HZ);
    } else {
        return -1;
    }
    
    // Map potmeter value from 1 - MAX_MOTOR_HZ
    return _lastPot1Value;
}
*/

void InputController::handleHorizontalButtons(RobotController & robotController, bool jointMode){
    uint16_t buttons = _spi0Manager.readHorizontalButtons();

    // increment the joint steps in the robot controller.
    if(jointMode){
        // only check buttons equal to the number of steppers
        for(int i = 0; i < robotController.getRobotConfig().numOfSteppers; i++){
            
            float velocity = robotController.getStepper(i).getMaxVelocity();
            // Default velocity is 0 when no button is pressed
            float targetVelocity = 0.0f;

            // do an and operation to check a speficific bit of the button state
            if(buttons & (1 << (i*2))){
                // positive velocity when even
                targetVelocity = velocity;

            } else if(buttons & (1 << (i*2 + 1))){
                // negative velocity when odd
                targetVelocity = -velocity;
            }
            // else targetVelocity stays 0 when button is released
            
            robotController.setTargetVelocity(i, targetVelocity);
        }
    } else {
        // always check all 6 DOF buttons for position mode
        for(int i = 0; i < 6; i++){
            if(buttons & (1 << (i*2))){
                // increment when is even
                robotController.incrementTargetPosition(i, true);

            } else if(buttons & (1 << (i*2 + 1))){
                // decrement when is odd
                robotController.incrementTargetPosition(i, false);

            } // else no change
        }
    }
}

void InputController::handleVerticalButtons(RobotController & robotController){
    uint16_t buttons = _spi0Manager.readVerticalButtons();

    // detect rising edges only: bits that are 1 now and were 0 before
    uint16_t rising = buttons & (~_lastVerticalButtonState);

    // store current state
    _lastVerticalButtonState = buttons;

    // loop over each vertical button, and handle only rising edges
    for(int i = 0; i < 16; i++){
        if(rising & (1u << i)){
            // Serial.print("Vertical Button ");
            // Serial.print(i);
            // Serial.println(" pressed");

            switch(i){
            case 0:
                robotController.nextRobot();
                break;
            case 1:
                robotController.resetPositions();
                break;
            case 2:
                // retry to init the ferris wheels 
                updateNumOfFerrisWheels(robotController.getNumOfFerrisWheels());
                break;
            case 3:
                // increase number of steppers and ferris wheels if possible
                // only for stepper tester and stepper & ferris tester modes
                if(robotController.getRobotConfig().name == STEPPER_TESTER || robotController.getRobotConfig().name == STEPPER_AND_FERRIS){
                    int newNumSteppersAndFerris = robotController.getNumOfSteppers() + 1;
                    if(newNumSteppersAndFerris > 8){
                        newNumSteppersAndFerris = 1;
                    }
              
                    robotController.changeRobot(robotController.getRobotConfig().name, newNumSteppersAndFerris);
                }
                break;
            case 4:
                // Tare ferris wheel sensors to current position
                robotController.ferrisWheelTareCurrentPosition();
                break;
            case 5:
                // Reset ferris wheel sensor tare
                robotController.ferrisWheelResetTare();
                break;
            case 8:
                robotController.saveStepperPositions();
                break;
            case 9:
                robotController.loadStepperPositions();
                break;
            case 15:
                // Toggle between end-effectors if supported
                if (robotController._kinematics) {
                    int currentEE = robotController._kinematics->getEndEffector();
                    int nextEE = (currentEE + 1) % EndEffector::COUNT;
                    robotController._kinematics->setEndEffector(static_cast<EndEffector>(nextEE));
                }
            default:
                break;
            }
        }
    }
}

void InputController::handleSwitches(RobotController & robotController){
    uint16_t switches = _spi0Manager.readSwitches();

    // Stepper control strategy
    if(switches & (1 << 0)) {
        _currentInputMode = JOINT_TARGET_MODE;
    } else {
        _currentInputMode = BUTTON_JOINT_MODE;
    }

    if(switches & (1 << 1)) {
        _currentInputMode = BUTTON_EE_CONTROL_MODE;
    }

    // Add more switch handling as needed

    // if(switches & (1 << 2)) {
    //     // Handle switch 2
    // } else {
    //     // Handle switch 2
    // }
}

void InputController::setMainValve(bool on) {
    _spi0Manager.setMainValve(on);
}

void InputController::setScreenRES(bool on) {
    _spi0Manager.setScreenRES(on);
}

void InputController::setScreenBLK(bool on) {
    _spi0Manager.setScreenBLK(on);
}

void InputController::setInputMode(InputModes newInputMode) {
    _currentInputMode = newInputMode;
}

InputModes InputController::getInputMode() {
    return _currentInputMode;
}